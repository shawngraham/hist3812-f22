---
interstitial:
date: {{date}}
tags: 
---

_the headings below can be re-arranged as suits your writing style, but all of these ideas should be addressed. Include citations as appropriate._

# Introduction 
```
Your **Reflection** will include your thoughts on all of the work in this module; tie what you’ve read and heard to what you’ve done. What is the main message of this module? How does it connect with your ideas for your Unessay? Your **Log** will be your record of your digital work in this module (including any Unessay work) - hiccups, successes, help found, help given. **Ephemera** is anything else you want to keep a record of, files created, screenshots, whatever.
```

## Win

## Fail

## Challenges

## Implications?

## Changes I'm making moving forward
_indicate how you adapted your work subsquent to the last round of feedback, as appropriate_

## Relevant Log Files