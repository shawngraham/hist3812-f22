---
Topic: {{title}}
Date: {{date:MMM d, YYYY}}
Course:
Class:
---

_You don't have to use this. It's just here if you want it. The idea is that when someone is speaking, you listen for the elements they harp on about, and make notes about what they're saying. You don't write down verbatim what they said! Then, afterwards, you re-write the 'Notes' into something a bit more coherent._

_If you're into visual note taking & sketching, use whatever you like, then drop a digital copy into obsidian; you can then embed it in a note using markdown image syntax `![title](filename.png)`. Other possibility is the Excalidraw plugin, which lets you draw within Obsidian._

### Notes
- Item

### Summary



