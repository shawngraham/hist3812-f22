---
title: The Unessay
date: 2021-07-23
tags: meta/help, meta/assessment
---

## The Unessay

Your [unessay](https://people.uleth.ca/~daniel.odonnell/Teaching/the-unessay) is a creative engagement around a historical or archaeological micro-episode. Through your unessay, you will provide an answer to the [main questions of this course](https://hist3812.netlify.app/syllabus/assessment/goals). I expect that most of you will use a game engine/technology, although other ‘immersive’ digital approaches are welcome. I am open to many suggestions; discuss with me sooner rather than later.

-   It should contain at least 30 minutes of immersive experience, broadly conceived
-   Its source code should be stored in a github repo (public or private; but if set to private, add ‘shawngraham’ as a collaborator)
-   All of the research and process notes should be provided, showing the evolution of the project from initial concept through to submitted ‘thing’. These can be text files in mardown format, in a subfolder of the repo.
-   There should be a game design document (or similar).
-   There should be a paradata document that situates what the experience is trying to do: use the HPS framework (or adapt it) to the situation.

An Obsidian Vault pre-populated with items that might help you, if you take a gameful approach, is available at [here](https://github.com/shawngraham/obsidian-game-design-vault).

The unessay will be assessed on how compelling and effective it is (following Paul Daniel O’Donnell):

> The main criterion is how well it all fits together. That is to say, how compelling and effective your work is.

> An unessay is compelling when it shows some combination of the following:
> 
> -   it is as interesting as its topic and approach allows
> -   it is as complete as its topic and approach allows (it doesn’t leave the audience thinking that important points are being skipped over or ignored)
> -   it is truthful (any questions, evidence, conclusions, or arguments you raise are honestly and accurately presented)

> In terms of presentation, an unessay is effective when it shows some combination of these attributes:
> 
> -   it is readable/watchable/listenable (i.e. the production values are appropriately high and the audience is not distracted by avoidable lapses in presentation)
> -   it is appropriate (i.e. it uses a format and medium that suits its topic and approach)
> -   it is attractive (i.e. it is presented in a way that leads the audience to trust the author and his or her arguments, examples, and conclusions).

#meta/assessment