# Create notes from your hypothesis annotations
- Create a new note, then insert the hypothesis template.
- When you run the `templater:insert template` command, and then select hypothesis templater command in a new note, Obsidian will first prompt you for your Hypothesis user token. You find that at your Hypothesis user page. Once you give that to Obsidian (which it will keep in a file here in your vault for you, so you only ever have to do it the first time), you will be prompted  for the url or date for the resource you annotated; it will then grab those annotations as separate notes. 
- remember that hypothesis is pretty handy for annotating pdfs too, if you open the pdf in your browser
- Interlink those notes to your daily notes, or your tutorial notes, as appropriate
- see [[Some Videos to Help#^ae6f1e]] 


#meta/help 
#meta/annotation
