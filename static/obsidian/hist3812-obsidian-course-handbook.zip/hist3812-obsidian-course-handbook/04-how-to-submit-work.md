---
title: Submitting work in hist3812
date: 2021-07-23
tags: meta/introduction, meta/help, meta/assessment
---

## Use the Templates
Being a digital historian means keeping track of what you’ve done, as a gift to your future self (ie, so that when you come back to something, you can pick up where you left off). As you go through the course, perhaps at the end of each week, you should **log** your technical work and store the relevant ephemera you have created in your github repository.

Make a new file here in obsidian, and use the `templates: insert template` command (ctrl+p to open the command palette, or hit the relevant icon on the tool ribbon) to insert the **log** template.

You can follow that template or modify it to suit your needs;  put into it any new terms you’ve encountered, commands you used, error messages you encountered, websites that helped, and so on. Bullet points and memos-to-self are fine.

There is a template for making notes for when we're in class too - the **in-class-note**. 

Finally, there is a template for the **reflection** piece that you will submit for grading at the end of each interstitial week.

## Logs & Reflections

I would suggest using this [repo](https://github.com/shawngraham/hist3812-starter) as a guide for organizing your work. When you're logged into Github, click on the 'fork' button to take a copy.

> **I am expecting to see a log for each week including the interstitial week, and a reflection document** at the end of each interstitial.

When you're ready, use your Finder or Windows Explorer to find the actual folder for your vault. You'll know you're in the right place because every file within it will have the file extension `.md`, ie, `log1-sept-14.md`.  Make sure you're logged into Github- then, when you want to upload material to Github, find the document, and drag-n-drop it onto your repository. Github will upload and then you hit the green 'commit' button.  Upload any other files or digital things you happen to make. 

## NOTIFY ME
For graded work (interstitials and unessay), use the Google webform to share the link to your repo/work with me. The form is live at:

**Make sure that if your repo is private you have added `shawngraham` as a collaborator.**

