# Zotero 

## Get what you need 
1. Download and install [Zotero](https://zotero.org) if you haven't already. Set it up and configure your browser so that when you find something via the Library's website (or Amazon, or wherever), you can one-click and make an entry in your own database of readings. 

2. Install the [Better Bibtext Plugin](https://retorque.re/zotero-better-bibtex/installation/) for zotero (which makes it easier to work with plain text files as we find here in Obsidian and Zotero).

## Annotate!

Within Zotero, if you double click on a pdf, a new tab will open. You can highlight text and add your own comments as you go. Try to have a system. For instance, use the colours in Zotero to indicate _why_ you're highlighting something:

Yellow - Questions/confusion
Red - Disagree
Green - Agree
Blue - Definitions / concepts
Purple - Important

## Extract Your Notes From Zotero Into Obsidian
1. cmd + p to open the command pallette
2. look for '**zotero - extract your notes from an item'**.
3. wait a few moments for the zotero selector to appear.
4. search for and select the item that you were annotating within zotero
5. a new note will appear in the zotero-notes folder in obsidian. Ta da! 
6. You can then refactor (use the 'note composer' command) the one big note into several small ones. Alternatively, in a brand new note you can link to the note and use the ^ symbol to link to a particular annotation

In any note that you create, you can link to the extracted note itself by typing the @ symbol and then the rest of the citekey; put the cite key in ``[[`` `]]`  to turn it into a link.

#### Warning 
If you have zotero on an ipad, and you have some kind of shared folder accessible between your computer and the ipad, there seems to be a glitch. Anything you annotate on your ipad in a shared folder needs to be moved to your main 'my library' on your computer, and then deleted from the shared folder. Otherwise you'll get an error when you go to extract the annotations.

(just for reference sake: [link to plugin documentation](https://github.com/mgmeyers/obsidian-zotero-integration/blob/main/docs/README.md) [template courtesy its creator](https://forum.obsidian.md/t/zotero-desktop-connector-import-templates/36310/2) )


#meta/help 
#meta/annotation